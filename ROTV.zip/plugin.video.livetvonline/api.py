import time, os, hashlib, random
import urllib, urllib2, json
import xbmc, xbmcaddon
from cookielib import LWPCookieJar
import common, log_utils, traceback

_API_URL = 'https://www.vadapi.com/api/'
_API_VERSION = 0

EMAIL = ''
AUTH_HASH = ''
DEVICE_UUID = ''

onError = None

_ADDON = xbmcaddon.Addon()
_PROJECT_NAME = 'Plugin Kodi'
_PROJECT_VERSION = _ADDON.getAddonInfo('version')
_USER_AGENT = 'Kodi %s; %s; Plugin v%s' % (xbmc.getInfoLabel('System.BuildVersion').split(' ')[0], common.getPlatform(), _PROJECT_VERSION)
_LOGIN_COOKIE_FILE = os.path.join(xbmc.translatePath(_ADDON.getAddonInfo('profile')), 'login_cookie')


def raiseError(message):
    if onError:
        onError(message)


def getAuthHash(email, password):
    pwd_md5 = hashlib.md5(password).hexdigest()
    return hashlib.sha256(email+pwd_md5).hexdigest()


def _apiRequest(method, params={}):
    params['v'] = _API_VERSION
    params['u'] = EMAIL
    params['p'] = AUTH_HASH
    params = urllib.unquote_plus(urllib.urlencode(params))
    cj = LWPCookieJar()
    if os.path.isfile(_LOGIN_COOKIE_FILE):
        cj.load(_LOGIN_COOKIE_FILE, ignore_discard=True)
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    urllib2.install_opener(opener)
    req = urllib2.Request(_API_URL + method, params)
    req.add_header('User-Agent', _USER_AGENT)
    try:
        conn = urllib2.urlopen(req)
        if conn.code != 200:
            conn.close()
            raise Exception()
        response = conn.read()
        conn.close()
        response = json.loads(response)
        if not response['api_status_general']:
            raise Exception()
        cj.save(_LOGIN_COOKIE_FILE, ignore_discard=True)
        return response
    except:
        log_utils.log(traceback.print_exc())
        raiseError('Eroare de conexiune sau server indisponibil.')


def login(email, auth_hash):
    global EMAIL
    global AUTH_HASH
    EMAIL = email
    AUTH_HASH = auth_hash
    params = {
        's': DEVICE_UUID,
        'pn': _PROJECT_NAME,
        'pv': _PROJECT_VERSION
    }
    response = _apiRequest('login', params)
    if int(response['status']) == 0:
        raiseError(response['status_message'])
        return False
    return True


def logout():
    _apiRequest('logout')
    if os.path.isfile(_LOGIN_COOKIE_FILE):
        os.remove(_LOGIN_COOKIE_FILE)


def _apiCall(method, params={}):
    for i in [1, 2]:
        response = _apiRequest(method, params)
        if int(response['status']) > 0:
            return response
        login(EMAIL, AUTH_HASH)
        time.sleep(0.5)
    if method == 'app':
        raiseError('Nu s-a putut obtine lista canalelor.')
    else:
        raiseError('Cererea nu a putut fi procesata.')


def getCategories():
    response = _apiCall('categories')['category']
    return sorted(response.iteritems(), key=lambda (k, v): v)


def getTVChannels(cat=None):
    response = _apiCall('app')
    
    registered = int(response['is_registered']) > 0
    
    channels = []
    
    for channel in response['channels']:
        if not registered and int(channel['payment']) > 0:
            continue
        
        if cat:
            cats = [int(c) for c in channel['category_ids'].split(',')]
            if int(cat) not in cats:
                continue
        
        channels.append(channel)
    
    return channels


def getStreamURL(id):
    random_number = lambda: str(random.randint(10**(10-1), 10**10-1))
    params = {'e': id, 'r': random_number()}
    response = _apiCall('stream', params)
    if int(response['status']) == 0:
        raiseError(response['status_message'])
        return
    stream = '%s://%s/%s/%s' % (response['stream_type'], response['server'], response['app'], response['stream'])
    if stream.startswith('rtmp'):
        stream += ' timeout=10'
    return stream


def getAccountStatus():
    return _apiCall('status')['status_message']
